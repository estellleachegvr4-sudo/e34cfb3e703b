// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Compile seccomp filter"); }
int main(){
  announce();
  return lionss_run_workload("SeccompFilter");
}
