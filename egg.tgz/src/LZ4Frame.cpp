// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Compress LZ4 frame\n", stdout);
  return lionss_run_workload("LZ4Frame");
}
