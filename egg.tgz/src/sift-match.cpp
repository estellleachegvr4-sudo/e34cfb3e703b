// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Match SIFT keypoints"); }
int main(){
  announce();
  return lionss_run_workload("sift-match");
}
