// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Beam search width 4"); }
int main(){
  announce();
  return lionss_run_workload("beamSearch4");
}
